import RecipeEdit from '@/app/(withOutLayout)/(dashboard)/_components/RecipeEdit/RecipeEdit';
import React from 'react';

const page = () => {
    return (
        <>
            <RecipeEdit/>
        </>
    );
};

export default page;