import AdminInsertForm from '@/app/(withOutLayout)/(dashboard)/dashboard/(admin)/_components/adminForm/AdminForm';
import React from 'react';


const page = () => {
    return (
        <>
            <AdminInsertForm/>
        </>
    );
};

export default page;