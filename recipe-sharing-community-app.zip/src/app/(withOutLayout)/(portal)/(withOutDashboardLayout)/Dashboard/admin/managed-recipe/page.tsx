import RecipeList from "@/app/(withOutLayout)/(dashboard)/_components/RecipeList/RecipeList";

const page = () => {
  return (
    <>
      <RecipeList />
    </>
  );
};

export default page;
