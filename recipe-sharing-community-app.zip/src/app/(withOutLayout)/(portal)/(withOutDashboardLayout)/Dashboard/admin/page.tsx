import Dashboard from '@/app/(withOutLayout)/(dashboard)/dashboard/(user)/_components/Dashboard/Dashboard';
import React from 'react';

const page = () => {
    return (
        <>
            <Dashboard/>
        </>
    );
};

export default page;