import ProfilePage from '@/app/(withOutLayout)/(dashboard)/_components/profile/ManageProfile';

const page = () => {
    return (
        <>
            <ProfilePage/>
        </>
    );
};

export default page;