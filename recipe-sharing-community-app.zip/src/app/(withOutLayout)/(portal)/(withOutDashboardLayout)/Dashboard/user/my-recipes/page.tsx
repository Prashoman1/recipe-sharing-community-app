import UserRecipeList from "@/app/(withOutLayout)/(dashboard)/dashboard/(user)/_components/UserRecipeList/UserRecipeList";



const page = () => {
    return (
        <>
           <div className="w-full py-5 pe-5">
                <UserRecipeList/>
            </div>
        </>
    );
};

export default page;