
import ProfilePage from '@/app/(withOutLayout)/(dashboard)/_components/profile/ManageProfile';
import React from 'react';

const page = () => {
    return (
        <>
            <ProfilePage/>
        </>
    );
};

export default page;