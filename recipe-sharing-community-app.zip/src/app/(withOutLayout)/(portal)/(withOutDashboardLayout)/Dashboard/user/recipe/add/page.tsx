// import RecipeForm from "@/app/(withOutLayout)/(dashboard)/_components/AddRecipe/AddRecipe";


const page = () => {
    return (
        <div className="py-5">
            {/* <RecipeForm/> */}
        </div>
    );
};

export default page;