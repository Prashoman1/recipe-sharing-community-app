import RecipeEdit from "@/app/(withOutLayout)/(dashboard)/_components/RecipeEdit/RecipeEdit";


const page = () => {
    return (
        <div>
            <RecipeEdit />
        </div>
    );
};

export default page;