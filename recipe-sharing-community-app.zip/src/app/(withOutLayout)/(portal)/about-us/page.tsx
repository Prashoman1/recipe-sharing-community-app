import AboutUs from "../_components/AboutUs/AboutUs";

const page = () => {
  return (
    <>
      <AboutUs />
    </>
  );
};

export default page;
