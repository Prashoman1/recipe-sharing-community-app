import UserTable from "../_components/AllUserList/AllUserList";
const page = () => {
    return (
        <>
            <UserTable />
        </>
    );
};

export default page;