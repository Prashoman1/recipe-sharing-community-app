import React from 'react';
import ContactUs from '../_components/ContactUs/ContactUs';

const page = () => {
    return (
        <>
            <ContactUs/>
        </>
    );
};

export default page;