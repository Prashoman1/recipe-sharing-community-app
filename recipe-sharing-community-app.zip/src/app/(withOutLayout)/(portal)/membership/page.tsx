import React from 'react';
import MembershipCard from '../_components/MemberShipCard/MemberShipCard';

const page = () => {
    return (
        <>
            <MembershipCard />
        </>
    );
};

export default page;