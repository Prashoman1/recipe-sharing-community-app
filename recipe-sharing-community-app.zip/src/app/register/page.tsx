import React from 'react';
import RegisterPage from '../(withOutLayout)/(portal)/_components/registerList/RegisterList';

const page = () => {
    return (
        <>
            <RegisterPage/>
        </>
    );
};

export default page;