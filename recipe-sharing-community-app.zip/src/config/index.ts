export const envConfig ={
    apiUrl : process.env.NEXT_PUBLIC_API_URL,
    imageHostApi : process.env.NEXT_PUBLIC_IMAGE_HOST_API,
}