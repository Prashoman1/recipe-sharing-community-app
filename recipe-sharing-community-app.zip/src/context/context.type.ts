/* eslint-disable @typescript-eslint/no-explicit-any */
export  type TContextType={
    user: any,
    setUser: any,
    refreshUser: any,
    setRefreshUser:any
}