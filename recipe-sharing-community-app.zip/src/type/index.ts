export type TTableHeader={
    title:string;
    key:string;
}